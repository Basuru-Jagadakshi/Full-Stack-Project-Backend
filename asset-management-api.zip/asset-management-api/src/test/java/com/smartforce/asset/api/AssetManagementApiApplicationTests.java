package com.smartforce.asset.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssetManagementApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
